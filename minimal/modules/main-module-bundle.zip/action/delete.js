print('Delete operation received:\n' + deleteOperation.json);

affectedRows.increment(3);