print('Insert operation received:\n' + insertOperation.json);

affectedRows.increment();